<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="63,63 1,63 1,1 51,1 63,13 	"/>
</g>
<rect x="7" y="31" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="50" height="32"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="39" x2="50" y2="39"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="47" x2="50" y2="47"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="55" x2="50" y2="55"/>
<rect x="15" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="34" height="19"/>
<rect x="38" y="5" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="5" height="11"/>
</svg>
